module.exports = {
    rules: {
        'no-undefined': [0]
    }
};
