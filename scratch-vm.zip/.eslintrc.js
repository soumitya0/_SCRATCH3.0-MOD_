module.exports = {
    extends: ['scratch', 'scratch/node', 'scratch/es6']
};
